from django.shortcuts import render

__author__ = 'bulos87'


def home(request):
    return render(request, 'index.html')

