from . import views
from django.conf.urls import url


__author__ = 'bulos87'

urlpatterns = [
    url(r'^project_info', views.project_info, name='project_info'),
    url(r'^peak_detection$', views.peak_detection, name='peak_detection'),
    url(r'^get_top_articles$', views.get_top_articles, name='get_top_articles'),
]
