from __future__ import unicode_literals

from django.db import models

# Create your models here.


class TopArticles(models.Model):
    date = models.DateField(null=False, blank=False)
    article_name = models.CharField(max_length=400, null=False, blank=False)
    en_peak_views = models.IntegerField(default=0, null=False, blank=False)
    en_rank = models.IntegerField(default=0, null=False, blank=False)
    en_views = models.CharField(default='', max_length=300, null=False, blank=False)
    fr_views = models.CharField(default='', max_length=300, null=False, blank=False)
    zh_views = models.CharField(default='', max_length=300, null=False, blank=False)
    es_views = models.CharField(default='', max_length=300, null=False, blank=False)
