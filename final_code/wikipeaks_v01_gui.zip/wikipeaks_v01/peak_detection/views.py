import json
import urllib2
import lxml.html
from django.shortcuts import render
from django.http import HttpResponse
from django.template import RequestContext
from django.conf import settings
from datetime import datetime, timedelta as td
from peak_detection.models import *


def project_info(request):
    return render(request, 'peak_detection/project_info.html')


def peak_detection(request):

    top_articles = []
    current_peak_date = '2016-01-01'

    if request.method == 'POST':

        # Gets the date
        current_peak_date = request.POST.get('peak_date', current_peak_date)

        daily_tops = TopArticles.objects.filter(date=current_peak_date).order_by('-en_rank')

        for i, top_article in enumerate(daily_tops):
            val_dict = dict()
            val_dict['position'] = top_article.en_rank
            val_dict['article'] = top_article.article_name
            val_dict['views'] = top_article.en_peak_views
            top_articles.append(val_dict)

    context = {'top_articles': top_articles,
               'current_peak_date': current_peak_date,
               'error': ''}

    return render(request, 'peak_detection/peak_detection.html', context)


def get_top_articles(request):
    response_dict = dict()

    if request.method == 'POST':

        # Get the Article
        article = request.POST.get('article', None)
        peak_date = request.POST.get('peak_date', None)

        if article and peak_date:

            # Prepares the Dates
            current_date = datetime.strptime(peak_date, '%Y-%m-%d')

            future_days_list = []
            past_days_list = []
            for i in range(7, 0, -1):
                past_days_list.append(current_date - td(days=i))

            for i in range(1, 8):
                future_days_list.append(current_date + td(days=i))

            complete_dates_range = past_days_list + [current_date] + future_days_list
            complete_dates_range_str = [date_r.strftime('%Y-%m-%d') for date_r in complete_dates_range]

            # Gets the views For the English Article
            en_article = TopArticles.objects.get(date=current_date, article_name=article)

            en_views = en_article.en_views.split('-')
            fr_views = en_article.fr_views.split('-')
            zh_views = en_article.zh_views.split('-')
            es_views = en_article.es_views.split('-')

            en_views = [int(x) for x in en_views]
            fr_views = [int(x) for x in fr_views]
            zh_views = [int(x) for x in zh_views]
            es_views = [int(x) for x in es_views]

            en_views_lst = [list(a) for a in zip(complete_dates_range_str, en_views)]
            fr_views_lst = [list(a) for a in zip(complete_dates_range_str, fr_views)]
            zh_views_lst = [list(a) for a in zip(complete_dates_range_str, zh_views)]
            es_views_lst = [list(a) for a in zip(complete_dates_range_str, es_views)]


            articles_list = []

            # English Views
            en_values = dict()
            en_values['article_name'] = 'en::%s' % en_article.article_name
            en_values['views'] = en_views_lst
            articles_list.append(en_values)

            # French Views
            fr_values = dict()
            fr_values['article_name'] = 'fr::%s' % en_article.article_name
            fr_values['views'] = fr_views_lst
            articles_list.append(fr_values)

            # Chinese Views
            zh_values = dict()
            zh_values['article_name'] = 'zh::%s' % en_article.article_name
            zh_values['views'] = zh_views_lst
            articles_list.append(zh_values)

            # Spanish Views
            es_values = dict()
            es_values['article_name'] = 'es::%s' % en_article.article_name
            es_values['views'] = es_views_lst
            articles_list.append(es_values)

            response_dict['articles'] = articles_list

            """
            # Crawl the Wikipedia Article
            base_url = 'https://en.wikipedia.org/wiki/%s'

            response = urllib2.urlopen(base_url % article)
            html = response.read()

            tree = lxml.html.fromstring(html)
            lang_table = tree.cssselect('div#p-lang')[0]

            all_links = lang_table.cssselect('div.body > ul > li > a.interlanguage-link-target')

            es_article = None
            zh_article = None
            fr_article = None

            for link in all_links:
                try:
                    href = link.xpath('@href')[0]
                    lang = link.xpath('@lang')[0]

                    if lang == 'es':
                        es_article = href.split('/')[-1]
                    elif lang == 'zh':
                        zh_article = href.split('/')[-1]
                    elif lang == 'fr':
                        fr_article = href.split('/')[-1]

                except IndexError:
                    pass

            for date_r in complete_dates_range:
                # Transform the Date into String
                date_r_str = date_r.strftime('%Y-%m-%d')

                # Create the keys
                # English key
                en_key = 'en::%s' % article
                #item = get_article_views(date_r_str, en_key)
                #print item

                # Spanish key
                if es_article:
                    es_key = 'es::%s' % es_article

                # Chinese key
                if zh_article:
                    zh_key = 'zh::%s' % zh_article

                # French key
                if fr_article:
                    fr_key = 'fr::%s' % fr_article

                #print(en_key, es_key, zh_key, fr_key)
            """
    return HttpResponse(
        json.dumps(response_dict),
        content_type="application/json"
    )
