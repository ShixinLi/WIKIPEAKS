from __future__ import unicode_literals

from django.apps import AppConfig


class PeakDetectionConfig(AppConfig):
    name = 'peak_detection'
